# CodeAlpha_Basic_Chatbot
A basic text-based chatbot that can have
conversations with users, using natural
language processing libraries like NLTK
to make the chatbot more conversational.
